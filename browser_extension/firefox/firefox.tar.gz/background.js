/**
 * Sends tab information to the local Flask server.
 * @param {tabs.Tab} tab 
 */
function sendTabInfo(tab) {
    // Safety check: Don't track internal browser pages or empty tabs
    if (!tab || !tab.url || tab.url.startsWith('about:') || tab.url.startsWith('moz-extension:')) {
        return;
    }

    const payload = {
        app: "Firefox",
        title: tab.title || "Untitled",
        url: tab.url
    };

    fetch("http://localhost:5001/tab_update", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    })
    .then(response => {
        if (!response.ok) {
            console.warn(`Tracker server responded with status: ${response.status}`);
        }
    })
    .catch(error => {
        console.error("Connection to Desktop Tracker failed. Is your Flask app running on port 5001?", error);
    });
}

// Listen for when a user switches to a different tab
browser.tabs.onActivated.addListener((activeInfo) => {
    browser.tabs.get(activeInfo.tabId)
        .then(sendTabInfo)
        .catch(err => console.error("Error retrieving tab:", err));
});

// Listen for when a page finishes loading or the URL changes
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Only send data when the page is fully loaded to ensure we have the final Title/URL
    if (changeInfo.status === "complete") {
        sendTabInfo(tab);
    }
});